
import { useState } from "react";
import "./App.css";

function App() {
  const [search, setSearch] = useState("");

  const translations = [
    { id: 1, title: "ترجمه مقاله مهندسی", description: "ترجمه‌ای دقیق از مقاله‌های مهندسی برق و مکانیک." },
    { id: 2, title: "خلاصه کتاب روان‌شناسی", description: "ترجمه و خلاصه‌ی کتاب‌های روان‌شناسی دانشگاهی." },
    { id: 3, title: "مقاله علوم انسانی", description: "مناسب برای دانشجویان علوم اجتماعی و فلسفه." }
  ];

  const filtered = translations.filter(t => t.title.includes(search) || t.description.includes(search));

  return (
    <div className="app">
      <header className="header">
        <h1>فروشگاه ترجمه‌های من</h1>
        <p>الهام گرفته از آرامش طبیعت - مناسب برای دانشجویان</p>
        <input placeholder="جستجو..." value={search} onChange={(e) => setSearch(e.target.value)} />
      </header>
      <main className="grid">
        {filtered.map(item => (
          <div key={item.id} className="card">
            <img src={`https://source.unsplash.com/400x200/?nature,forest&sig=${item.id}`} alt="img" />
            <h2>{item.title}</h2>
            <p>{item.description}</p>
            <button>خرید و دانلود</button>
          </div>
        ))}
      </main>
      <footer className="footer">© ۲۰۲۵ فروشگاه من</footer>
    </div>
  );
}

export default App;
